create view view_product as
select `demoview`.`products`.`productName` AS `productName`, `demoview`.`products`.`productPrice` AS `productPrice`
from `demoview`.`products`;

